package com.hanstoquica.dtf;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class RetrieveDTFInfo extends AsyncTask<Object, String, List<HashMap<String,String>>> {

    private Exception exception;
    public AsyncResponse delegate = null;

    @SuppressLint("LongLogTag")
    @Override
    protected List<HashMap<String, String>> doInBackground(Object... objects) {
        DownloadURL downloadURL = new DownloadURL();

        List<HashMap<String, String>> allData = null;
        try {
            String query = (String) objects[0];
            String query2 = "";
            if(query.equals("Default_Data")){
                String auxJSONMessage = downloadURL.ReadTheURL("https://www.datos.gov.co/resource/axk9-g2nh.json?$select=max(fechacorte) as fechacorte");
                JSONArray jsonArray = null;
                JSONObject jsonObject = null;

                jsonArray = new JSONArray(auxJSONMessage);
                jsonObject = (JSONObject) jsonArray.get(0);
                String lastDate = jsonObject.getString("fechacorte");
                System.out.println(lastDate);

                auxJSONMessage = downloadURL.ReadTheURL("https://www.datos.gov.co/resource/axk9-g2nh.json?$where=fechacorte not in('" + lastDate + "')&$select=max(fechacorte)");
                jsonArray = new JSONArray(auxJSONMessage);
                jsonObject = (JSONObject) jsonArray.get(0);
                String previousDate = jsonObject.getString("max_fechacorte");
                System.out.println(previousDate);

                query = "https://www.datos.gov.co/resource/axk9-g2nh.json?$where=fechacorte='" + lastDate + "'&$order=tasa desc";
                query2 = "https://www.datos.gov.co/resource/axk9-g2nh.json?$where=fechacorte='" + previousDate + "'&$order=tasa desc";
            }
            else if(query.equals("Detailed_Data")){
                Log.d("RetrieveDTFInfo_doInBackground", "Call from detailed data");
                Date currentTime = Calendar.getInstance().getTime();
                Calendar previousCalendar = Calendar.getInstance();
                previousCalendar.setTime(currentTime);
                previousCalendar.add(Calendar.DAY_OF_YEAR, -30);
                Date previousTime = previousCalendar.getTime();
                Log.d("RetrieveDTFInfo_doInBackground", currentTime.toString());
                Log.d("RetrieveDTFInfo_doInBackground", previousTime.toString());
                String previousTimeString = String.valueOf(previousTime.getYear() + 1900) + "-";
                previousTimeString = previousTimeString + String.valueOf(previousTime.getMonth()) + "-";
                if(previousTime.getDay() == 0)
                    previousTimeString = previousTimeString + String.valueOf(previousTime.getDay()+1) + "T00:00:00";
                else
                    previousTimeString = previousTimeString + String.valueOf(previousTime.getDay()) + "T00:00:00";
                String currentTimeString = String.valueOf(currentTime.getYear() + 1900) + "-";
                currentTimeString = currentTimeString + String.valueOf(currentTime.getMonth()) + "-";
                currentTimeString = currentTimeString + String.valueOf(currentTime.getDay()) + "T00:00:00";
                Log.d("RetrieveDTFInfo_doInBackground", previousTimeString);
                Log.d("RetrieveDTFInfo_doInBackground", currentTimeString);

                String dTipoEntidad = (String) String.valueOf(objects[1]);
                String dCodigoEntidad = (String) String.valueOf(objects[2]);
                String dUCA = (String) String.valueOf(objects[3]);
                String dSubcuenta = (String) String.valueOf(objects[4]);

                query = "https://www.datos.gov.co/resource/axk9-g2nh.json?$where=fechacorte between'" + previousTimeString + "' and '" + currentTimeString + "'";
                query = query + "and tipoentidad=" + dTipoEntidad + " and codigoentidad=" + dCodigoEntidad + " and uca=" + dUCA + " and subcuenta=" + dSubcuenta;
                query = query + "&$order=fechacorte";
                Log.d("RetrieveDTFInfo_doInBackground", query);
                //https://www.datos.gov.co/resource/axk9-g2nh.json?$where=fechacorte between'2020-9-1T00:00:00' and '2020-10-2T00:00:00'&$order=fechacorte

            }
            String jsonMessage = downloadURL.ReadTheURL(query);

            DataParser dataParser = new DataParser();
            allData = dataParser.parse(jsonMessage);

            if(!query2.isEmpty()){
                jsonMessage = downloadURL.ReadTheURL(query2);

                List<HashMap<String, String>> allData2 = null;
                allData2 = dataParser.parse(jsonMessage);
                for (int i = 0; i < allData2.size(); i++) {
                    HashMap<String, String> datum = allData2.get(i);
                    allData2.get(i).put("nombreentidad", "PassingInfo" + allData2.get(i).get("nombreentidad"));
                    Log.d("RetrieveDTFInfo_doInBackground", datum.get("nombreentidad"));
                }
                allData.addAll(allData2);
            }

            for (int i = 0; i < allData.size(); i++) {
                HashMap<String, String> datum = allData.get(i);
                Log.d("RetrieveDTFInfo_doInBackground", datum.get("nombreentidad"));
            }
            return allData;

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return allData;
    }

    @SuppressLint("LongLogTag")
    @Override
    protected void onPostExecute(List<HashMap<String,String>> result) {
        Log.d("RetrieveDTFInfo_onPostExecute", "Trying to call the method in main");
        Log.d("RetrieveDTFInfo_onPostExecute", result.toString());
        delegate.processFinish(result);
    }

    public interface AsyncResponse {
        void processFinish(List<HashMap<String,String>> output);
    }
}
