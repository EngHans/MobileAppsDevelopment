package com.hanstoquica.dtf;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.helper.StaticLabelsFormatter;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DetailLevel1 extends AppCompatActivity implements RetrieveDTFInfo.AsyncResponse{

    private LineGraphSeries<DataPoint> series1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_level1);

        ImageView imageView = (ImageView) findViewById(R.id.logo2);

        TextView entidadNombre = (TextView) findViewById(R.id.entidadNombre);
        TextView uca = (TextView) findViewById(R.id.ucaDesc);
        TextView period = (TextView) findViewById(R.id.descripcion);
        TextView fechaCorte = (TextView) findViewById(R.id.dueDate);
        TextView monto = (TextView) findViewById(R.id.valueValue);
        TextView tipoentidad = (TextView) findViewById(R.id.entidadTipo);


        Bundle extras = getIntent().getExtras();

        if (extras != null){
            imageView.setImageResource(extras.getInt("logo"));
            entidadNombre.setText(extras.getString("nombreentidad"));
            uca.setText(extras.getString("nombre_unidad_de_captura"));
            period.setText(extras.getString("descripcion"));
            fechaCorte.setText(extras.getString("fechacorte"));
            monto.setText(extras.getString("monto") + " (en miles de pesos)");

            switch (extras.getInt("tipoentidad")){
                case 1:
                    tipoentidad.setText("Bancos");
                    break;
                case 2:
                    tipoentidad.setText("Corporaciones Financieras");
                    break;
                case 3:
                    tipoentidad.setText("Corporaciones de Ahorro y Vivienda");
                    break;
                case 4:
                    tipoentidad.setText("Compañías de Financiamiento");
                    break;
                case 22:
                    tipoentidad.setText("Instituciones Oficiales Especiales");
                    break;
                case 32:
                    tipoentidad.setText("Corporaciones Financieras");
                    break;
                default:
                    tipoentidad.setText("Sin tipo");
            }

        }

        Object transferData[] = new Object[5];
        transferData[0] = "Detailed_Data";
        transferData[1] = extras.getInt("tipoentidad");
        transferData[2] = extras.getInt("codigoentidad");
        transferData[3] = extras.getInt("uca");
        transferData[4] = extras.getInt("subcuenta");


        RetrieveDTFInfo retrieveDTFInfo = new RetrieveDTFInfo();
        retrieveDTFInfo.delegate = this;
        retrieveDTFInfo.execute(transferData);


    }

    @Override
    public void processFinish(List<HashMap<String, String>> output) {
        GraphView graphView = (GraphView) findViewById(R.id.dataPlot);
        series1 = new LineGraphSeries<>();
        List<String> horizontalLabels = new ArrayList<String>();
        String auxLabelString = "";
        int labelModulus = 0;

        for(int i = 0; i < output.size(); i++){
            series1.appendData(new DataPoint(i, Double.parseDouble(output.get(i).get("tasa"))), true, 100);
            auxLabelString = output.get(i).get("fechacorte");
            labelModulus = (output.size()/3);
            if(labelModulus == 0)
                labelModulus = 1;
            System.out.println(output.size());
            System.out.println(labelModulus);
            System.out.println(i);
            System.out.println(i%labelModulus);
            if(i%labelModulus == 0)
                auxLabelString = auxLabelString.substring(5, 10);
            else
                auxLabelString = "";
            //2020-09-01T00:00:00.000
            horizontalLabels.add(auxLabelString);
        }
        graphView.addSeries(series1);
        System.out.println(series1.toString());

        graphView.getViewport().setYAxisBoundsManual(true);
        Double differenceValue = series1.getHighestValueY() - series1.getLowestValueY();
        graphView.getViewport().setMaxY(series1.getHighestValueY() + (differenceValue * 0.1));
        graphView.getViewport().setMinY(series1.getLowestValueY() - (differenceValue * 0.1));
        graphView.getViewport().setXAxisBoundsManual(true);

        String[] horizontalLabelsArray = new String[horizontalLabels.size()];
        horizontalLabels.toArray(horizontalLabelsArray);

        StaticLabelsFormatter staticLabelsFormatter = new StaticLabelsFormatter(graphView);
        staticLabelsFormatter.setHorizontalLabels(horizontalLabelsArray);

        graphView.getGridLabelRenderer().setLabelFormatter(staticLabelsFormatter);

    }
}