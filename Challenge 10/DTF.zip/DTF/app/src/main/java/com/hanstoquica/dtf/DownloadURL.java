package com.hanstoquica.dtf;

import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class DownloadURL {

    public String ReadTheURL(String placeURL) throws IOException {
        String Data = "";
        InputStream inputStream = null;
        HttpURLConnection httpURLConnection = null;

        try {
            Log.d("DownloadURL_ReadTheURL", "Trying to readURL");
            URL url = new URL(placeURL);
            Log.d("DownloadURL_ReadTheURL", "URL Instancing success");
            httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.connect();

            Log.d("DownloadURL_ReadTheURL", "HttpCon Success");

            inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuffer stringBuffer = new StringBuffer();

            String line = "";

            while( (line = bufferedReader.readLine()) != null ){
                stringBuffer.append(line);
            }

            Data = stringBuffer.toString();
            bufferedReader.close();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            Log.d("DownloadURL_ReadTheURL", "Trying to close the connection objects");
            if (inputStream!=null)
                inputStream.close();
            if (httpURLConnection!=null)
                httpURLConnection.disconnect();
        }

        return Data;
    }

}
