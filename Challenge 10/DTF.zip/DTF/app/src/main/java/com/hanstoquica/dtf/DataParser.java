package com.hanstoquica.dtf;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DataParser {
    private HashMap<String, String> getDatum(JSONObject googlePlaceJSON){
        HashMap<String, String> datum = new HashMap<>();
        String tipoentidad = "";
        String codigoentidad = "";
        String nombreentidad = "";
        String fechacorte = "";
        String uca = "";
        String nombre_unidad_de_captura = "";
        String subcuenta = "";
        String descripcion = "";
        String tasa = "";
        String monto = "";

        try {
            tipoentidad = googlePlaceJSON.getString("tipoentidad");
            codigoentidad = googlePlaceJSON.getString("codigoentidad");
            nombreentidad = googlePlaceJSON.getString("nombreentidad");
            fechacorte = googlePlaceJSON.getString("fechacorte");
            uca = googlePlaceJSON.getString("uca");
            nombre_unidad_de_captura = googlePlaceJSON.getString("nombre_unidad_de_captura");
            subcuenta = googlePlaceJSON.getString("subcuenta");
            descripcion = googlePlaceJSON.getString("descripcion");
            tasa = googlePlaceJSON.getString("tasa");
            monto = googlePlaceJSON.getString("monto");

            datum.put("tipoentidad", tipoentidad);
            datum.put("codigoentidad", codigoentidad);
            datum.put("nombreentidad", nombreentidad);
            datum.put("fechacorte", fechacorte);
            datum.put("uca", uca);
            datum.put("nombre_unidad_de_captura", nombre_unidad_de_captura);
            datum.put("subcuenta", subcuenta);
            datum.put("descripcion", descripcion);
            datum.put("tasa", tasa);
            datum.put("monto", monto);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return datum;
    }

    private List<HashMap<String, String>> getAllData(JSONArray jsonArray){
        int counter = jsonArray.length();
        List<HashMap<String, String>> dataList = new ArrayList<>();

        HashMap<String, String> datum = null;

        for(int i = 0; i<counter; i++){
            try {
                datum = getDatum( (JSONObject) jsonArray.get(i) );
                dataList.add(datum);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return dataList;
    }

    public List<HashMap<String, String>> parse(String jSONdata){
        JSONArray jsonArray = null;
        JSONObject jsonObject;

        try {
            jsonArray = new JSONArray(jSONdata);
            Log.d("DataParser_parse", String.valueOf(jsonArray.length()) + " rows");
            return getAllData(jsonArray);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return getAllData(jsonArray);
    }
}
