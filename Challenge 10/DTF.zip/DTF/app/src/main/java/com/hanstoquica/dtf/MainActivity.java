package com.hanstoquica.dtf;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.Console;
import java.io.IOException;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity implements RetrieveDTFInfo.AsyncResponse {

    class MyAdapter extends ArrayAdapter<String>{
        // Done with https://www.youtube.com/watch?v=5Tm--PHhbJo - Custom listView in android with item click - Android WorldClub
        Context context;

        List<String> rTitle;
        List<String> rDescription;
        List<String> rPeriod;
        List<Integer> rTipoEntidad;
        List<String> rTasa;
        List<String> rDifference;
        List<Integer> rLogo;
        List<Integer> rOptimism;
        List<Integer> rTipoEntidadOriginal;
        List<Integer> rCodigoEntidad;
        List<Integer> rUCA;
        List<Integer> rSubcuenta;

        MyAdapter (Context c, List<String> title, List<String> description, List<Integer> tipoentidad, List<String> tasa, List<Integer> logo, List<String> period, List<String> difference, List<Integer> optimism,
        List<Integer> tipoentidadOriginal, List<Integer> codigoEntidad, List<Integer> UCA, List<Integer> subcuenta){
            super(c, R.layout.row, R.id.title, title);
            this.context = c;
            this.rTitle = title;
            this.rDescription = description;
            this.rTipoEntidad = tipoentidad;
            this.rTasa = tasa;
            this.rLogo = logo;
            this.rPeriod = period;
            this.rDifference = difference;
            this.rOptimism = optimism;
            this.rTipoEntidadOriginal = tipoentidadOriginal;
            this.rCodigoEntidad = codigoEntidad;
            this.rUCA = UCA;
            this.rSubcuenta = subcuenta;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row = layoutInflater.inflate(R.layout.row, parent, false);

            TextView companyTitle = row.findViewById(R.id.title);
            TextView companyDescription = row.findViewById(R.id.brief);
            ImageView companyLogo = row.findViewById(R.id.logo);
            TextView companyTasa = row.findViewById(R.id.rate);
            TextView companyPeriod = row.findViewById(R.id.brief2);
            TextView companyGrowth = row.findViewById(R.id.growth);
            View companyType = row.findViewById(R.id.companyType);

            companyTitle.setText(rTitle.get(position));
            companyDescription.setText(rDescription.get(position));
            companyTasa.setText(rTasa.get(position));
            companyLogo.setImageResource(rLogo.get(position));
            companyPeriod.setText(rPeriod.get(position));
            companyType.setBackgroundColor(rTipoEntidad.get(position));
            if(rDifference.get(position).isEmpty())
                companyGrowth.setVisibility(View.GONE);
            else
                companyGrowth.setText(rDifference.get(position));

            companyGrowth.setTextColor(rOptimism.get(position));

            return row;
        }

    }

    public String compareRateInList(List<HashMap<String,String>> old, HashMap<String,String> value){
        String lastTipoEntidad = value.get("tipoentidad");
        String lastCodigoEntidad = value.get("codigoentidad");
        String lastUCA = value.get("uca");
        String lastSubcuenta = value.get("subcuenta");
        String previousTipoEntidad;
        String previousCodigoEntidad;
        String previousUCA;
        String previousSubcuenta;
        String returningString = "";

        for(int i = 0; i < old.size(); i++){
            previousTipoEntidad = old.get(i).get("tipoentidad");
            previousCodigoEntidad = old.get(i).get("codigoentidad");
            previousUCA = old.get(i).get("uca");
            previousSubcuenta = old.get(i).get("subcuenta");
            if (previousCodigoEntidad.equals(lastCodigoEntidad) && previousTipoEntidad.equals(lastTipoEntidad) && previousUCA.equals(lastUCA) && previousSubcuenta.equals(lastSubcuenta)){
                double difference;
                difference = Double.parseDouble(value.get("tasa")) - Double.parseDouble(old.get(i).get("tasa"));
                DecimalFormat df = new DecimalFormat("#0.00");
                if(difference > 0)
                    returningString = "▲ +" + df.format(difference) + "%";
                else if (difference == 0)
                    returningString = "▶ +" + df.format(difference) + "%";
                else
                    returningString = "▼ " + df.format(difference) + "%";
            }
        }

        return returningString;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Object transferData[] = new Object[1];
        transferData[0] = "Default_Data";


        RetrieveDTFInfo retrieveDTFInfo = new RetrieveDTFInfo();
        retrieveDTFInfo.delegate = this;
        retrieveDTFInfo.execute(transferData);

    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @SuppressLint("LongLogTag")
    @Override
    public void processFinish(List<HashMap<String,String>> output){
        Log.d("MainActivity_processFinish", "Method has been called");
        findViewById(R.id.loadingPanel).setVisibility(View.GONE);

        List<HashMap<String,String>> previous = new ArrayList<>();
        List<HashMap<String,String>> last = new ArrayList<>();
        for(int i = 0; i < output.size(); i++){
            if(output.get(i).get("nombreentidad").startsWith("PassingInfo")){
                previous.add(output.get(i));
            }
            else
                last.add(output.get(i));
        }

        output = last;
        Toast.makeText(this, "Showing " + output.size() + " details.", Toast.LENGTH_SHORT).show();

        ListView lv;

        lv = (ListView) findViewById(R.id.dataList);

        // Instanciating an array list (you don't need to do this,
        // you already have yours).
        List<String> mTitle = new ArrayList<String>();
        List<String> mDescription = new ArrayList<String>();
        List<Integer> mTipoEntidad = new ArrayList<Integer>();
        List<Integer> mCodigoEntidad = new ArrayList<Integer>();
        List<String> mTasa = new ArrayList<String>();
        List<Integer> mLogoId = new ArrayList<Integer>();
        List<String> mPeriod = new ArrayList<String>();
        List<String> mDifference = new ArrayList<String>();
        List<Integer> mOptimism = new ArrayList<Integer>();
        List<Integer> mTipoEntidadOriginal = new ArrayList<Integer>();
        List<Integer> mUCA = new ArrayList<Integer>();
        List<Integer> mSubcuenta = new ArrayList<Integer>();
        Double auxTasa;
        String auxDifference;
        int auxTipoEntidad;
        int auxCodigoEntidad;
        int uca;
        int period;

        HashMap<Integer, HashMap<Integer, Integer>> logosDB = new HashMap<>();

        HashMap<Integer, Integer> financieraLogosDB = new HashMap<>();
        financieraLogosDB.put(117, R.drawable.credifamilia);
        financieraLogosDB.put(121, R.drawable.juriscoop);
        financieraLogosDB.put(8, R.drawable.giros);
        financieraLogosDB.put(108, R.drawable.dann);
        financieraLogosDB.put(118, R.drawable.oi);
        financieraLogosDB.put(46, R.drawable.coltefinanciera);
        financieraLogosDB.put(122, R.drawable.rci);
        financieraLogosDB.put(31, R.drawable.gm);
        financieraLogosDB.put(26, R.drawable.tuya);
        financieraLogosDB.put(120, R.drawable.lahipotecaria);

        HashMap<Integer, Integer> financiera32LogosDB = new HashMap<>();
        financiera32LogosDB.put(5, R.drawable.confiar);
        financiera32LogosDB.put(4, R.drawable.cotrafa);
        financiera32LogosDB.put(3, R.drawable.coofinep);
        financiera32LogosDB.put(2, R.drawable.jfk);
        financiera32LogosDB.put(1, R.drawable.cfa);

        HashMap<Integer, Integer> bankLogosDB = new HashMap<>();
        bankLogosDB.put(13, R.drawable.bbva);
        bankLogosDB.put(51, R.drawable.procredit);
        bankLogosDB.put(49, R.drawable.avvillas);
        bankLogosDB.put(43, R.drawable.agrario);
        bankLogosDB.put(52, R.drawable.bancamia);
        bankLogosDB.put(54, R.drawable.bancoomeva);
        bankLogosDB.put(1, R.drawable.bogota);
        bankLogosDB.put(30, R.drawable.cajasocial);
        bankLogosDB.put(58, R.drawable.coopcentral);
        bankLogosDB.put(39, R.drawable.davivienda);
        bankLogosDB.put(23, R.drawable.occidente);
        bankLogosDB.put(62, R.drawable.mibanco);
        bankLogosDB.put(57, R.drawable.pichincha);
        bankLogosDB.put(60, R.drawable.mundomujer);
        bankLogosDB.put(12, R.drawable.gnbsuda);
        bankLogosDB.put(53, R.drawable.bancow);
        bankLogosDB.put(63, R.drawable.serfinanza);
        bankLogosDB.put(9, R.drawable.citi);
        bankLogosDB.put(56, R.drawable.falabella);
        bankLogosDB.put(42, R.drawable.scotia);
        bankLogosDB.put(2, R.drawable.popular);
        bankLogosDB.put(7, R.drawable.bancolombia);
        bankLogosDB.put(55, R.drawable.finandina);
        bankLogosDB.put(6, R.drawable.itau);

        HashMap<Integer, Integer> credLogosDB = new HashMap<>();
        credLogosDB.put(11, R.drawable.corficolombiana);
        credLogosDB.put(42, R.drawable.bnp);
        credLogosDB.put(41, R.drawable.jpmorgan);

        HashMap<Integer, Integer> corpLogosDB = new HashMap<>();
        corpLogosDB.put(1, R.drawable.bancoldex);
        corpLogosDB.put(2, R.drawable.findeter);
        corpLogosDB.put(4, R.drawable.finagro);



        logosDB.put(1, bankLogosDB);
        logosDB.put(2,credLogosDB);
        logosDB.put(4, financieraLogosDB);
        logosDB.put(22, corpLogosDB);
        logosDB.put(32, financiera32LogosDB);

        for(int i = 0; i < output.size(); i++){
            auxDifference = compareRateInList(previous,output.get(i));
            mDifference.add(auxDifference);

            if(auxDifference.startsWith("▲"))
                mOptimism.add(0xFF00C205);//mOptimism.add(0xFF18A352);
            else if(auxDifference.startsWith("▼"))
                mOptimism.add(0xFFFF0000);
            else if(auxDifference.startsWith("▶"))
                mOptimism.add(0xFFA9A9A9);
            else
                mOptimism.add(0x00000000);

            mTitle.add(output.get(i).get("nombreentidad"));
            auxTipoEntidad = Integer.parseInt(output.get(i).get("tipoentidad"));
            auxCodigoEntidad = Integer.parseInt(output.get(i).get("codigoentidad"));
            switch (auxTipoEntidad){
                case 1:
                    mTipoEntidad.add(0xFF00FF00);
                    break;
                case 2:
                    mTipoEntidad.add(0xFFFFFF00);
                    break;
                case 4:
                    mTipoEntidad.add(0xFFFF0000);
                    break;
                case 22:
                    mTipoEntidad.add(0xFF0000FF);
                    break;
                case 32:
                    mTipoEntidad.add(0xFFFF00FF);
                    break;
                default:
                    mTipoEntidad.add(0xFF00FFFF);
                    break;
            }

            mCodigoEntidad.add(auxCodigoEntidad);
            mTipoEntidadOriginal.add(auxTipoEntidad);
            mUCA.add(Integer.parseInt(output.get(i).get("uca")));
            mSubcuenta.add(Integer.parseInt(output.get(i).get("subcuenta")));

            auxTasa = Double.parseDouble(output.get(i).get("tasa"));
            DecimalFormat df = new DecimalFormat();
            if (auxTasa < 10)
                df.applyPattern("#0.00");
            else
                df.applyPattern("#.0");
            mTasa.add(df.format(auxTasa) + "%");

            mLogoId.add(logosDB.getOrDefault(auxTipoEntidad, financieraLogosDB).getOrDefault(auxCodigoEntidad, R.mipmap.ic_launcher));

            uca = Integer.parseInt(output.get(i).get("uca"));
            period = Integer.parseInt(output.get(i).get("subcuenta"));

            switch (uca){
                case 1:
                    mDescription.add("Emisión de CDT");
                    switch (period){
                        case 10:
                        case 40:
                            mPeriod.add("A 30 días");
                            break;
                        case 20:
                            mPeriod.add("31-44 días");
                            break;
                        case 30:
                            mPeriod.add("A 45 días");
                            break;
                        case 50:
                            mPeriod.add("A 60 días");
                            break;
                        case 60:
                            mPeriod.add("61-89 días");
                            break;
                        case 70:
                            mPeriod.add("A 90 días");
                            break;
                        case 80:
                            mPeriod.add("91-119 días");
                            break;
                        case 90:
                            mPeriod.add("A 120 días");
                            break;
                        case 100:
                            mPeriod.add("121-179 días");
                            break;
                        case 110:
                            mPeriod.add("A 180 días");
                            break;
                        case 120:
                            mPeriod.add("181-359 días");
                            break;
                        case 130:
                            mPeriod.add("A 360 días");
                            break;
                        case 140:
                            mPeriod.add("+360 días");
                            break;
                        case 900:
                            mPeriod.add("Captación Oficina");
                            break;
                        case 910:
                            mPeriod.add("Captación Tesorería");
                            break;
                        default:
                            mPeriod.add("No 'period' statement found");
                            break;
                    }
                    break;
                case 2:
                    mDescription.add("Emisión de CDAT");
                    switch (period){
                        case 10:
                        case 40:
                            mPeriod.add("A 30 días");
                            break;
                        case 20:
                            mPeriod.add("2-14 días");
                            break;
                        case 30:
                            mPeriod.add("15-29 días");
                            break;
                        case 50:
                            mPeriod.add("31-90 días");
                            break;
                        case 60:
                            mPeriod.add("91-180 días");
                            break;
                        case 70:
                            mPeriod.add("+181 días");
                            break;
                        case 900:
                            mPeriod.add("Captación Oficina");
                            break;
                        case 910:
                            mPeriod.add("Captación Tesorería");
                            break;
                        default:
                            mPeriod.add("No 'period' statement found");
                            break;
                    }
                    break;
                case 3:
                    mDescription.add("Mercado Monetario");
                    switch (period){
                        case 10:
                            mPeriod.add("1-5 días hábiles (USD)");
                            break;
                        case 20:
                            mPeriod.add("1 día hábil (overnight, moneda local)");
                            break;
                        case 30:
                            mPeriod.add("2-5 días hábiles (COP)");
                            break;
                        case 40:
                            mPeriod.add("+5 días (COP)");
                            break;
                        case 900:
                            mPeriod.add("Establecimientos de Cŕedito");
                            break;
                        case 910:
                            mPeriod.add("Otras entidades financieras");
                            break;
                        default:
                            mPeriod.add("No 'period' statement found");
                            break;
                    }
                    break;
                case 4:
                    mDescription.add("Interbancarios");
                    switch (period){
                        case 10:
                            mPeriod.add("1-5 días hábiles (USD)");
                            break;
                        case 20:
                            mPeriod.add("1 día hábil (overnight, moneda local)");
                            break;
                        case 30:
                            mPeriod.add("2-5 días hábiles (COP)");
                            break;
                        case 40:
                            mPeriod.add("+5 días (COP)");
                            break;
                        case 900:
                            mPeriod.add("Establecimientos de Cŕedito");
                            break;
                        case 910:
                            mPeriod.add("Otras entidades financieras");
                            break;
                        default:
                            mPeriod.add("No 'period' statement found");
                            break;
                    }
                    break;
                case 5:
                    mDescription.add("Repo Pasivos");
                    switch (period){
                        case 10:
                            mPeriod.add("1-5 días hábiles (USD)");
                            break;
                        case 20:
                            mPeriod.add("1 día hábil (overnight, moneda local)");
                            break;
                        case 30:
                            mPeriod.add("2-5 días hábiles (COP)");
                            break;
                        case 40:
                            mPeriod.add("6-29 días hábiles (COP)");
                            break;
                        case 50:
                            mPeriod.add("A 30 días hábiles (COP)");
                            break;
                        case 60:
                            mPeriod.add("31-44 días hábiles (COP)");
                            break;
                        case 70:
                            mPeriod.add("A 45 días hábiles (COP)");
                            break;
                        case 80:
                            mPeriod.add("46-59 días hábiles (COP)");
                            break;
                        case 90:
                            mPeriod.add("A 60 días hábiles (COP)");
                            break;
                        case 100:
                            mPeriod.add("61-89 días hábiles (COP)");
                            break;
                        case 110:
                            mPeriod.add("A 90 días hábiles (COP)");
                            break;
                        case 120:
                            mPeriod.add("91-119 días hábiles (COP)");
                            break;
                        case 130:
                            mPeriod.add("A 120 días hábiles (COP)");
                            break;
                        case 140:
                            mPeriod.add("121-179 días hábiles (COP)");
                            break;
                        case 150:
                            mPeriod.add("A 180 días hábiles (COP)");
                            break;
                        case 160:
                            mPeriod.add("181-359 días hábiles (COP)");
                            break;
                        case 180:
                            mPeriod.add("Bancos");
                            break;
                        case 190:
                            mPeriod.add("Corporaciones Financieras");
                            break;
                        case 200:
                            mPeriod.add("Bolsa de Valores");
                            break;
                        case 210:
                            mPeriod.add("Compañías de Financiamiento Comercial");
                            break;
                        case 220:
                            mPeriod.add("Otras entidades financieras");
                            break;
                        case 230:
                            mPeriod.add("Banco de la República");
                            break;
                        case 250:
                            mPeriod.add("Entidades del Sector Público");
                            break;
                        case 260:
                            mPeriod.add("Residentes del Exterior");
                            break;
                        case 270:
                            mPeriod.add("Sociedades fiduciarias");
                            break;
                        case 280:
                            mPeriod.add("Administradoras de Pensiones y Cesantias");
                            break;
                        case 290:
                            mPeriod.add("Sociedades Comisionistas de bolsas");
                            break;
                        case 300:
                            mPeriod.add("Otras");
                            break;
                        default:
                            mPeriod.add("No 'period' statement found");
                            break;
                    }
                    break;
                case 6:
                    mDescription.add("Repo Activos");
                    switch (period){
                        case 20:
                            mPeriod.add("1 día hábil (overnight, moneda local)");
                            break;
                        case 30:
                            mPeriod.add("2-5 días hábiles (COP)");
                            break;
                        case 40:
                            mPeriod.add("6-29 días hábiles (COP)");
                            break;
                        case 50:
                            mPeriod.add("A 30 días hábiles (COP)");
                            break;
                        case 60:
                            mPeriod.add("31-44 días hábiles (COP)");
                            break;
                        case 110:
                            mPeriod.add("A 90 días hábiles (COP)");
                            break;
                        case 180:
                            mPeriod.add("Bancos");
                            break;
                        case 190:
                            mPeriod.add("Corporaciones Financieras");
                            break;
                        case 200:
                            mPeriod.add("Bolsa de Valores");
                            break;
                        case 210:
                            mPeriod.add("Compañías de Financiamiento Comercial");
                            break;
                        case 220:
                            mPeriod.add("Otras entidades financieras");
                            break;
                        case 230:
                            mPeriod.add("Banco de la República");
                            break;
                        case 250:
                            mPeriod.add("Entidades del Sector Público");
                            break;
                        case 270:
                            mPeriod.add("Sociedades fiduciarias");
                            break;
                        case 280:
                            mPeriod.add("Administradoras de Pensiones y Cesantias");
                            break;
                        case 290:
                            mPeriod.add("Sociedades Comisionistas de bolsas");
                            break;
                        default:
                            mPeriod.add("No 'period' statement found");
                            break;
                    }
                    break;
                default:
                    mDescription.add(output.get(i).get("nombre_unidad_de_captura") + " " + output.get(i).get("tipoentidad") + " " + output.get(i).get("codigoentidad"));
            }

        }

        MyAdapter adapter = new MyAdapter(this, mTitle, mDescription, mTipoEntidad, mTasa, mLogoId, mPeriod, mDifference, mOptimism, mTipoEntidadOriginal, mCodigoEntidad, mUCA, mSubcuenta);
        lv.setAdapter(adapter);

        final List<HashMap<String, String>> finalOutput = output;
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                System.out.println("Arg0 " + parent);
                System.out.println("Arg1 " + view);
                System.out.println("Arg2 " + position);
                System.out.println("Arg3 " + id);

                System.out.println("adapter info:" + parent.getAdapter());

                MyAdapter theAdapter = (MyAdapter) parent.getAdapter();

/*                System.out.println("The Adapter = " + theAdapter);
                System.out.println("Description = " + theAdapter.rTipoEntidad.get(position));
                System.out.println("Description = " + theAdapter.rTasa.get(position));*/

                Bundle dataBundle = new Bundle();

                dataBundle.putInt("tipoentidad", theAdapter.rTipoEntidadOriginal.get(position));
                dataBundle.putInt("codigoentidad", theAdapter.rCodigoEntidad.get(position));
                dataBundle.putInt("uca", theAdapter.rUCA.get(position));
                dataBundle.putInt("subcuenta", theAdapter.rSubcuenta.get(position));
                dataBundle.putInt("logo", theAdapter.rLogo.get(position));

                int auxTiposEntidad;
                int auxCodigosEntidad;
                int auxUCAs;
                int auxSubcuentas;

                for(int i = 0; i < finalOutput.size(); i++){
                    auxTiposEntidad = Integer.parseInt(finalOutput.get(i).get("tipoentidad"));
                    auxCodigosEntidad = Integer.parseInt(finalOutput.get(i).get("codigoentidad"));
                    auxUCAs = Integer.parseInt(finalOutput.get(i).get("uca"));
                    auxSubcuentas = Integer.parseInt(finalOutput.get(i).get("subcuenta"));
                    if(auxTiposEntidad == dataBundle.getInt("tipoentidad") && auxCodigosEntidad == dataBundle.getInt("codigoentidad") && auxUCAs == dataBundle.getInt("uca") && auxSubcuentas == dataBundle.getInt("subcuenta")){
                        dataBundle.putString("nombreentidad", finalOutput.get(i).get("nombreentidad"));
                        dataBundle.putString("fechacorte", finalOutput.get(i).get("fechacorte"));
                        dataBundle.putString("nombre_unidad_de_captura", finalOutput.get(i).get("nombre_unidad_de_captura"));
                        dataBundle.putString("descripcion", finalOutput.get(i).get("descripcion"));
                        dataBundle.putString("monto", finalOutput.get(i).get("monto"));
                    }
                }

                Intent intent = new Intent(getApplicationContext(), DetailLevel1.class);
                intent.putExtras(dataBundle);
                startActivity(intent);
            }
        });

    }
}