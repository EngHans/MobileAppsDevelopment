package com.example.sairamkrishna.gpsaccess;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceFragmentCompat;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        final SharedPreferences preferences = getSharedPreferences("PREFS", 0);

        final SharedPreferences.Editor ed = preferences.edit();

        int proximityRadius = preferences.getInt("radius", 5000);
        final int radiusInKm = proximityRadius / 1000;

        final TextView textView = (TextView) findViewById(R.id.radiusInput);
        textView.setText(String.valueOf(radiusInKm));

        final SeekBar seekBar = (SeekBar) findViewById(R.id.seekBar);
        seekBar.setProgress(radiusInKm);

        textView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                int newValue = Integer.parseInt(s.toString());
                if (newValue < 1){
                    Toast.makeText(SettingsActivity.this, "Only positive values allowed", Toast.LENGTH_SHORT).show();
                    newValue = 1;
                }
                else if(newValue > 20){
                    Toast.makeText(SettingsActivity.this, "Up to 20km allowed", Toast.LENGTH_SHORT).show();
                    newValue = 20;
                }
                seekBar.setProgress(newValue);
                ed.putInt("radius", newValue * 1000);
                ed.commit();

            }
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                textView.setText(String.valueOf(seekBar.getProgress()));
                ed.putInt("radius", seekBar.getProgress() * 1000);
                ed.commit();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    }

    public static class SettingsFragment extends PreferenceFragmentCompat {
        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {

        }
    }
}