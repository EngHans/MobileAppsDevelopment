﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Text.RegularExpressions;

public class GameBackEnd : MonoBehaviour
{
    public char[] canvas = new char[] {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '};

    public char OPEN_SPOT = ' ';
    public char HUMAN_PLAYER = 'X';
    public char COMPUTER_PLAYER = 'O';
    public int humanMove = -1;
    private int win = 0;
    private char turn;
    private string temporary = "Temporary String";


    public static System.Random ran = new System.Random();

    // Start is called before the first frame update
    int checkForWinner(){
        // Check horizontal wins
        for (int i = 0; i <= 6; i += 3)	{
            if (canvas[i] == HUMAN_PLAYER &&
                    canvas[i+1] == HUMAN_PLAYER &&
                    canvas[i+2]== HUMAN_PLAYER)
                return 2;
            if (canvas[i] == COMPUTER_PLAYER &&
                    canvas[i+1]== COMPUTER_PLAYER &&
                    canvas[i+2] == COMPUTER_PLAYER)
                return 3;
        }

        // Check vertical wins
        for (int i = 0; i <= 2; i++) {
            if (canvas[i] == HUMAN_PLAYER &&
                    canvas[i+3] == HUMAN_PLAYER &&
                    canvas[i+6]== HUMAN_PLAYER)
                return 2;
            if (canvas[i] == COMPUTER_PLAYER &&
                    canvas[i+3] == COMPUTER_PLAYER &&
                    canvas[i+6]== COMPUTER_PLAYER)
                return 3;
        }

        // Check for diagonal wins
        if ((canvas[0] == HUMAN_PLAYER &&
                canvas[4] == HUMAN_PLAYER &&
                canvas[8] == HUMAN_PLAYER) ||
                (canvas[2] == HUMAN_PLAYER &&
                        canvas[4] == HUMAN_PLAYER &&
                        canvas[6] == HUMAN_PLAYER))
            return 2;
        if ((canvas[0] == COMPUTER_PLAYER &&
                canvas[4] == COMPUTER_PLAYER &&
                canvas[8] == COMPUTER_PLAYER) ||
                (canvas[2] == COMPUTER_PLAYER &&
                        canvas[4] == COMPUTER_PLAYER &&
                        canvas[6] == COMPUTER_PLAYER))
            return 3;

        // Check for tie
        for (int i = 0; i < canvas.Length; i++) {
            // If we find a number, then no one has won yet
            if (canvas[i] != HUMAN_PLAYER && canvas[i] != COMPUTER_PLAYER)
                return 0;
        }

        // If we make it through the previous loop, all places are taken, so it's a tie
        return 1;
    }

    void clearCanvas(){
        for (int i = 0; i < canvas.Length; i++)
        {
            canvas[i] = OPEN_SPOT;
        }
    }

    int getComputerMove(){
        return ran.Next(9);
    }

    int getUserMove(){
        return humanMove;
    }

    public void onPushedButton(Object obj){
        temporary = obj.name;
        humanMove = int.Parse(Regex.Match(obj.name, @"\d+").Value);
    }

    void printCanvas2Console(){
        Debug.Log("GameBackEnd.cs > printCanvas2Console > Printing Canvas to terminal");
        for (int i = 0; i < 3; i++)
        {
            Debug.Log(canvas[(i*3)] + " | " + canvas[(i*3)+1] + " | " + canvas[(i*3)+2]);
        }
    }

    void showOnUI(){
        Object[] gameObjects;
        gameObjects = Object.FindObjectsOfType(typeof(GameObject));
        for (int i = 0; i < gameObjects.Length; i++) {
            if(gameObjects[i].name.Contains("Pos")){
                ( gameObjects[i] as GameObject).GetComponentInChildren<Text>().text = canvas[int.Parse(Regex.Match(gameObjects[i].name, @"\d+").Value)].ToString();
            }            
        }
    }

    bool setMove(char player, int pos){
        humanMove = -1;
        if (pos < 9 && pos >= 0){
            if(canvas[pos] == OPEN_SPOT){
                canvas[pos] = player;
                return true;
            }
            else
                return false;
        }
        return false;
    }

    void Start()
    {
        turn = HUMAN_PLAYER;    // Human starts first
        clearCanvas();
        printCanvas2Console();
    }

    void terminalGame(){
		print("TerminalGame " + win);
		// Keep looping until someone wins or a tie
		if (win == 0)
		{	
			if (turn == HUMAN_PLAYER)
			{
                if(setMove(HUMAN_PLAYER, getUserMove())){
                    turn = COMPUTER_PLAYER;
                }
			}
			else
			{
                if(setMove(COMPUTER_PLAYER, getComputerMove()))
    				turn = HUMAN_PLAYER;
			}
		}

		printCanvas2Console();

    }

    // Update is called once per frame
    void Update()
    {
    KeyCode keycode;
    if (Application.isEditor) keycode =  KeyCode.O;
        else keycode =  KeyCode.Space;

        if (Input.GetKeyDown(keycode))
        {
            print("space key was pressed");
            clearCanvas();
            turn = HUMAN_PLAYER;
        }
        else{
            foreach(KeyCode vKey in System.Enum.GetValues(typeof(KeyCode))){
                if(Input.GetKey(vKey)){
                    if(vKey.ToString().Contains("eypad"))
                        if(Regex.Match(vKey.ToString(), @"\d+").Value != ""){
                            print(Regex.Match(vKey.ToString(), @"\d+").Value);
                            humanMove = int.Parse(Regex.Match(vKey.ToString(), @"\d+").Value);
                        }
                }
            }
        }
    win = checkForWinner();
    terminalGame();
    humanMove = -1;
    showOnUI();

    print("win " + win);
    print("HumanMove" + humanMove);
    print(temporary);
    }
}
