package com.example.sairamkrishna.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;

import java.util.ArrayList;
import java.util.HashMap;

//import android.support.v7.app.ActionBarActivity;

//public class MainActivity extends ActionBarActivity {
public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    public final static String EXTRA_MESSAGE = "MESSAGE";
    private ListView obj;
    DBHelper mydb;
    private SearchView searchOnList;
    SimpleAdapter adapter;


    ArrayList<HashMap<String, String>> data;
    private String[] titleArray,subItemArray;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        searchOnList = findViewById(R.id.searchView);

        mydb = new DBHelper(this);
        ArrayList array_list = mydb.getAllContacts();
        ArrayList array_list_classes = mydb.getAllContactsClass();

        obj = (ListView)findViewById(R.id.listView1);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);

        ArrayAdapter<CharSequence> arrayAdapter = ArrayAdapter.createFromResource(this,
                R.array.planets_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinner.setAdapter(arrayAdapter);

        spinner.setOnItemSelectedListener(this);

        data = new ArrayList<HashMap<String, String>>();

        String[] titleArray = new String[array_list.size()];
        titleArray = (String[]) array_list.toArray(titleArray);

        String[] subItemArray = new String[array_list_classes.size()];
        subItemArray = (String[]) array_list_classes.toArray(subItemArray);

        for(int i=0;i<titleArray.length;i++){
            HashMap<String,String> datum = new HashMap<String, String>();
            datum.put("RouterName", titleArray[i]);
            datum.put("RouterIP", subItemArray[i]);
            data.add(datum);
        }
        adapter = new SimpleAdapter(this, data, android.R.layout.simple_list_item_2, new String[] {"RouterName", "RouterIP"}, new int[] {android.R.id.text1, android.R.id.text2});
        obj.setAdapter(adapter);

        obj.setOnItemClickListener(new OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,long arg3) {
                // TODO Auto-generated method stub
                int id_To_Search = arg2 + 1;
                System.out.println("Arg0 " + arg0);
                System.out.println("Arg1 " + arg1);
                System.out.println("Arg2 " + arg2);
                System.out.println("Arg3 " + arg3);

                System.out.println("Text1 " + arg1.toString());
                System.out.println(arg0.findViewById(R.id.textView1));
                System.out.println(arg1.findViewById(R.id.textView2));


                HashMap<String, String> item = (HashMap<String, String>) arg0.getItemAtPosition(arg2);
                String value = item.get("RouterName");
                String key = item.get("RouterIP");

                System.out.println("Text1 " + value);
                System.out.println("Text2 " + key);


                Cursor rs = mydb.getSingleContactId(value, key);
                rs.moveToFirst();

                int id = Integer.parseInt(rs.getString(rs.getColumnIndex(DBHelper.CONTACTS_COLUMN_ID)));

                if (!rs.isClosed())  {
                    rs.close();
                }

                Bundle dataBundle = new Bundle();
                dataBundle.putInt("id", id);

                Intent intent = new Intent(getApplicationContext(),DisplayContact.class);

                intent.putExtras(dataBundle);
                startActivity(intent);
            }
        });


        searchOnList.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                MainActivity.this.adapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                MainActivity.this.adapter.getFilter().filter(newText);
                return false;
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        super.onOptionsItemSelected(item);

        switch(item.getItemId()) {
            case R.id.item1:Bundle dataBundle = new Bundle();
                dataBundle.putInt("id", 0);

                Intent intent = new Intent(getApplicationContext(),DisplayContact.class);
                intent.putExtras(dataBundle);

                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public boolean onKeyDown(int keycode, KeyEvent event) {
        if (keycode == KeyEvent.KEYCODE_BACK) {
            moveTaskToBack(true);
        }
        return super.onKeyDown(keycode, event);
    }

    public void onItemSelected(AdapterView<?> parent, View view,
                               int pos, long id) {
        // An item was selected. You can retrieve the selected item using
        // parent.getItemAtPosition(pos)

        String string = parent.getItemAtPosition(pos).toString();

        if (string.equals(getResources().getString(R.string.all)))
                string = "";

        MainActivity.this.adapter.getFilter().filter(string);

    }

    public void onNothingSelected(AdapterView<?> parent) {
        // Another interface callback
    }
}